def main():
	f = open('sliceAway.py', 'r')
	for line in f:
		print line[:-1]

main()
