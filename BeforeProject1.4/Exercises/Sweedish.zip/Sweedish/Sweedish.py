from Module import *

def main():
    print "Enter a word:",
    word = raw_input()
    print translate(word);

main();
